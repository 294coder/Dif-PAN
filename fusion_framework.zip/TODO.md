# 需要做的一些事

1. 跑消融实验
    a. 只有mwsa的dcformer

2. 将dcformer_mwsa中的cross-mwsa，其中的window_size计算换成运行时计算（不依赖于定义的dict）
