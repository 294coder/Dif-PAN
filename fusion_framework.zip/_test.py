# import signal
# import time
# import sys
# import traceback

# COLOR_RED = '\033[91m'
# COLOR_GREEN = '\033[92m'
# COLOR_YELLOW = '\033[93m'
# COLOR_BLUE = '\033[94m'
# COLOR_RESET = '\033[0m'

# def colored_print(s, color):
#     if color == 'r':
#         s = COLOR_RED + s + COLOR_RESET
#     elif color == 'g':
#         s = COLOR_GREEN + s + COLOR_RESET
#     elif color == 'y':
#         s = COLOR_YELLOW + s + COLOR_RESET
#     elif color == 'b':
#         s = COLOR_BLUE + s + COLOR_RESET
#     return s
        

# def do_something():
#     print('i am doing something')
    
# def exit_call(sig, frame):
#     print(f'met error {sig}, i am in {frame}')
#     sys.exit(-1)
    
# def at_exit_call(exc_type, exc_value, exc_trace_back):
#     print(colored_print(f'exiting: met {exc_type}', 'r'))
    
#     print('='*40, 'trace back', '='*40)
#     traceback.print_tb(exc_trace_back)
#     print('='*92)
    
# def in_func_raise():
#     print('in func raising some error')
#     # raise ValueError
#     time.sleep(200)

# def main():
#     print('here is main func')
    
#     # signal.signal(signal.SIGINT, exit_call)
#     # signal.signal(signal.SIGTERM, exit_call)
    
#     sys.excepthook = at_exit_call

#     in_func_raise()
    
#     print('main: done')
    
# main()
        
        
        
################# save in several mat files #################
import h5py
import numpy as np
import os
import os.path as osp
import scipy.io as io
from tqdm import tqdm


file = r'/media/office-401-remote/Elements SE/cao/ZiHanCao/exps/panformer/visualized_img/data_gppnn_wv2_unref.mat'

name = file.split('/')[-1].strip('.mat')
path = f'/media/office-401-remote/Elements SE/cao/ZiHanCao/exps/panformer/visualized_img/{name}'
save_prefix = 'output_mulExm_'
if not osp.exists(path):
    os.mkdir(path)
    print(f'make dir {name}')
else:
    print(f'exist dir {name}')
    
    
mat_file = io.loadmat(file)
print(f'has keys: {mat_file.keys()}')

sr = mat_file.get('sr')
if sr is None:
    print('has no key sr')
else:
    bar = tqdm(range(sr.shape[0]))
    for i in bar:
        save_path = osp.join(path, save_prefix+f'{i}.mat')
        sr_i = np.transpose(sr[i-1, ...], [1,2,0])
        save_d = {'sr': sr_i}
        io.savemat(save_path, save_d)
        bar.set_description(f'save {i}.mat')
        
import numpy as np
import glob
import matplotlib.pyplot as plt
import cv2

#### save jpg
const = 2047
files = glob.glob(path+'/*.mat')
files = sorted(files, key=lambda x: int(os.path.basename(x).split('_')[-1].strip('.mat')))

print(f'find files in {path}')
f_len = len(files)
nrows = 4
ncols = np.ceil(f_len/4).astype('int')
fig, axes = plt.subplots(ncols=ncols, nrows=nrows, figsize=(ncols, nrows), dpi=200)
axes = axes.flatten()
for ax in axes: ax.set_axis_off()
for i, f in enumerate(files):
    print(f)
    sr = io.loadmat(f).get('sr') / const
    sr=sr.clip(0, 1)
    show_sr = (sr[..., [0,1,2]]*255).astype('uint8')
    # for j in range(3):
    #     show_sr[..., j] = cv2.equalizeHist(show_sr[..., j])
    axes[i].imshow(show_sr)
    axes[i].set_axis_off()
    
    if i == 0:
        print(f'shape as {sr.shape}')
        
plt.tight_layout(pad=0.5)
# plt.show()
plt.savefig('./visualized_img/'+file.strip('.mat').split('/')[-1]+'.jpg', dpi=200)