classdef NoTestMethods < TestCase
   methods
      function self = NoTestMethods(name)
         self = self@TestCase(name);
      end
   end
end