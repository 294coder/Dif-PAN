function testSin

assertElementsAlmostEqual(sin(pi), 0);